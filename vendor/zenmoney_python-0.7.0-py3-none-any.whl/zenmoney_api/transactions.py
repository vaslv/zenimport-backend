"""Builders produce full wire objects; they never send or persist anything."""
import math
import time
from copy import deepcopy
from datetime import date as Date
from decimal import Decimal
from typing import Any, Unpack, cast
from collections.abc import Mapping
from .models import Number, Transaction, TransactionOptions, TransactionFields, BaseTransactionOptions
from .protocol import EntityData
from uuid import uuid4
from .protocol import DELETABLE, timestamp, encode_json

CREATION_DEFAULTS: EntityData = {key: None for key in (
    'merchant', 'originalPayee', 'reminderMarker', 'opIncome', 'opIncomeInstrument',
    'opOutcome', 'opOutcomeInstrument', 'latitude', 'longitude', 'qrCode', 'source',
    'incomeBankID', 'outcomeBankID')}
CREATION_DEFAULTS['viewed'] = True


def _finite_number(value: Any) -> bool:
    if isinstance(value, Decimal):
        return value.is_finite()
    return type(value) is int or (type(value) is float and math.isfinite(value))


def _amount(value: Number, *, positive: bool = False) -> Number:
    if not _finite_number(value) or value < 0 or (positive and value == 0):
        raise ValueError('Expected a finite nonnegative amount')
    return value


def _id(value: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError('Expected a nonempty account ID')
    return value


def _positive_int(value: int) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError('Expected a positive integer ID')
    return value


def transaction(*, user: int, date: str, income_account: str, outcome_account: str,
                income_instrument: int, outcome_instrument: int, income: Number,
                outcome: Number, categories: list[str] | None = None,
                payee: str | None = None, comment: str | None = None,
                merchant: str | None = None, id: str | None = None,
                now: int | None = None, **fields: Unpack[TransactionFields]) -> Transaction:
    """Build a posted operation. IDs/timestamps can be supplied for deterministic drafts."""
    if not isinstance(date, str) or Date.fromisoformat(date).isoformat() != date:
        raise ValueError('Expected ISO calendar date')
    stamp = timestamp(int(time.time()) if now is None else now)
    if categories is not None and (not isinstance(categories, list) or not all(isinstance(t, str) and t for t in categories)):
        raise ValueError('Expected category IDs or None')
    for value in (payee, comment, merchant):
        if value is not None and not isinstance(value, str):
            raise ValueError('Expected optional text')
    result: EntityData = {**CREATION_DEFAULTS, 'mcc': None, 'id': _id(id) if id is not None else str(uuid4()),
        'created': stamp, 'changed': stamp, 'user': _positive_int(user), 'deleted': False, 'hold': False,
        'date': date, 'incomeAccount': _id(income_account), 'outcomeAccount': _id(outcome_account),
        'incomeInstrument': _positive_int(income_instrument), 'outcomeInstrument': _positive_int(outcome_instrument),
        'income': _amount(income), 'outcome': _amount(outcome), 'tag': deepcopy(categories),
        'payee': payee, 'comment': comment, 'merchant': merchant}
    allowed = set(CREATION_DEFAULTS) | {'mcc', 'hold', 'deleted'}
    if any(k not in allowed for k in fields):
        raise ValueError('Unsupported optional transaction field')
    result.update(fields)
    for name in ('opIncome', 'opOutcome'):
        if result[name] is not None:
            _amount(result[name])
        if (result[name] is None) != (result[name+'Instrument'] is None):
            raise ValueError('Original amount and instrument must be supplied together')
        if result[name+'Instrument'] is not None:
            _positive_int(result[name+'Instrument'])
    for name, limit in (('latitude', 90), ('longitude', 180)):
        if result[name] is not None and (not _finite_number(result[name]) or not -limit <= result[name] <= limit):
            raise ValueError('Invalid coordinates')
    if type(result['deleted']) is not bool or (result['hold'] is not None and type(result['hold']) is not bool):
        raise ValueError('Invalid transaction flags')
    if type(result['viewed']) is not bool:
        raise ValueError('Invalid viewed flag')
    if result['mcc'] is not None and (type(result['mcc']) is not int or result['mcc'] < 0):
        raise ValueError('Invalid MCC')
    for name in ('originalPayee', 'reminderMarker', 'qrCode', 'source', 'incomeBankID', 'outcomeBankID'):
        if result[name] is not None and not isinstance(result[name], str):
            raise ValueError('Invalid optional transaction text')
    encode_json(result)
    return cast(Transaction, result)


def expense(*, account: str, instrument: int, amount: Number, **kwargs: Unpack[TransactionOptions]) -> Transaction:
    return transaction(income_account=account, outcome_account=account,
        income_instrument=instrument, outcome_instrument=instrument,
        income=0, outcome=_amount(amount, positive=True), **kwargs)


def income(*, account: str, instrument: int, amount: Number, **kwargs: Unpack[TransactionOptions]) -> Transaction:
    return transaction(income_account=account, outcome_account=account,
        income_instrument=instrument, outcome_instrument=instrument,
        income=_amount(amount, positive=True), outcome=0, **kwargs)


def transfer(*, from_account: str, to_account: str, from_instrument: int,
             to_instrument: int, amount_out: Number, amount_in: Number, **kwargs: Unpack[TransactionOptions]) -> Transaction:
    if from_account == to_account:
        raise ValueError('Transfer requires different accounts')
    return transaction(income_account=to_account, outcome_account=from_account,
        income_instrument=to_instrument, outcome_instrument=from_instrument,
        income=_amount(amount_in, positive=True), outcome=_amount(amount_out, positive=True), **kwargs)


def debt(*, action: str, account: str, debt_account: str, instrument: int,
         amount: Number, payee: str, **kwargs: Unpack[BaseTransactionOptions]) -> Transaction:
    """lend/repay: cash → debt; borrow/collect: debt → cash. Both use cash currency."""
    if action not in ('lend', 'borrow', 'repay', 'collect'):
        raise ValueError('Unknown debt action')
    if not isinstance(payee, str) or not payee.strip():
        raise ValueError('Debt requires a counterparty')
    outgoing = action in ('lend', 'repay')
    return transfer(from_account=account if outgoing else debt_account,
        to_account=debt_account if outgoing else account,
        from_instrument=instrument, to_instrument=instrument,
        amount_out=amount, amount_in=amount, payee=payee, **kwargs)


def update(entity: Mapping[str, Any], *, now: int | None = None, **fields: Any) -> EntityData:
    """Copy a complete fetched entity, retaining unknown fields. Identity is immutable."""
    if any(k in fields for k in ('id', 'user', 'created', 'changed')):
        raise ValueError('Cannot replace identity or timestamps in an update')
    result = deepcopy(dict(entity))
    result.update(deepcopy(fields))
    result['changed'] = timestamp(int(time.time()) if now is None else now)
    encode_json(result)
    return result


def deletion(kind: str, id: str, *, user: int, now: int | None = None) -> EntityData:
    if kind not in DELETABLE:
        raise ValueError('This entity cannot be deleted by ID')
    return {'object': kind, 'id': _id(id), 'user': _positive_int(user),
            'stamp': timestamp(int(time.time()) if now is None else now)}


def clear_budget(budget: Mapping[str, Any], *, now: int | None = None) -> EntityData:
    """Budget has a composite identity; clear amounts/locks instead of deleting by ID."""
    return update(budget, now=now, income=0, outcome=0, incomeLock=False, outcomeLock=False)
