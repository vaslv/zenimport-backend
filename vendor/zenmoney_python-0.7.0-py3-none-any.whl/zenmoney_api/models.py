"""Wire field names match the public API. Reads retain all unknown server fields.

TypedDicts help editors; low-level diff performs structural, not full schema validation.
Use full fetched entities for updates; do not send partial TypedDicts as patches.
"""
from typing import TypedDict, Literal, Required
from decimal import Decimal

Number = int | float | Decimal

class Instrument(TypedDict, total=False):
    id: int
    changed: int
    title: str
    shortTitle: str
    symbol: str
    rate: Number

class Company(TypedDict, total=False):
    id: int
    changed: int
    title: str
    fullTitle: str | None
    www: str | None
    country: str | None

class User(TypedDict, total=False):
    id: int
    changed: int
    login: str | None
    currency: int
    parent: int | None

class Entity(TypedDict, total=False):
    id: str
    changed: int
    user: int

class Account(Entity, total=False):
    private: bool
    balanceCorrectionType: str
    role: int | None
    instrument: int | None
    company: int | None
    type: Literal['cash', 'ccard', 'checking', 'loan', 'deposit', 'emoney', 'debt']
    title: str
    syncID: list[str] | None
    balance: Number | None
    startBalance: Number | None
    creditLimit: Number | None
    inBalance: bool
    savings: bool | None
    enableCorrection: bool
    enableSMS: bool
    archive: bool
    capitalization: bool | None
    percent: Number | None
    startDate: str | None
    endDateOffset: int | None
    endDateOffsetInterval: Literal['day', 'week', 'month', 'year'] | None
    payoffStep: int | None
    payoffInterval: Literal['month', 'year'] | None

class Tag(Entity, total=False):
    archive: bool
    staticId: str | None
    title: str
    parent: str | None
    icon: str | None
    picture: str | None
    color: int | None
    showIncome: bool
    showOutcome: bool
    budgetIncome: bool
    budgetOutcome: bool
    required: bool | None

class Merchant(Entity, total=False):
    mcc: int | None
    title: str

class Movement(Entity, total=False):
    incomeInstrument: int
    incomeAccount: str
    income: Number
    outcomeInstrument: int
    outcomeAccount: str
    outcome: Number
    tag: list[str] | None
    merchant: str | None
    payee: str | None
    comment: str | None

class Transaction(Movement, total=False):
    created: int
    deleted: bool
    hold: bool | None
    originalPayee: str | None
    date: str
    mcc: int | None
    reminderMarker: str | None
    opIncome: Number | None
    opIncomeInstrument: int | None
    opOutcome: Number | None
    opOutcomeInstrument: int | None
    latitude: Number | None
    longitude: Number | None
    viewed: bool
    qrCode: str | None
    source: str | None
    incomeBankID: str | None
    outcomeBankID: str | None

class Reminder(Movement, total=False):
    interval: Literal['day', 'week', 'month', 'year'] | None
    step: int | None
    points: list[int] | None
    startDate: str
    endDate: str | None
    notify: bool

class ReminderMarker(Movement, total=False):
    isForecast: bool
    date: str
    reminder: str
    state: Literal['planned', 'processed', 'deleted']
    notify: bool

class Budget(TypedDict, total=False):
    isIncomeForecast: bool
    isOutcomeForecast: bool
    changed: int
    user: int
    tag: str | None
    date: str
    income: Number
    incomeLock: bool
    outcome: Number
    outcomeLock: bool

class Deletion(TypedDict):
    id: str
    object: str
    user: int
    stamp: int


class TransactionFields(TypedDict, total=False):
    """Optional wire fields accepted by the transaction builder."""
    originalPayee: str | None
    reminderMarker: str | None
    opIncome: Number | None
    opIncomeInstrument: int | None
    opOutcome: Number | None
    opOutcomeInstrument: int | None
    latitude: Number | None
    longitude: Number | None
    mcc: int | None
    hold: bool | None
    deleted: bool
    viewed: bool
    qrCode: str | None
    source: str | None
    incomeBankID: str | None
    outcomeBankID: str | None


class BaseTransactionOptions(TransactionFields, total=False):
    """Shared keywords of all operation builders, excluding the counterparty."""
    user: Required[int]
    date: Required[str]
    categories: list[str] | None
    comment: str | None
    merchant: str | None
    id: str | None
    now: int | None


class TransactionOptions(BaseTransactionOptions, total=False):
    payee: str | None
