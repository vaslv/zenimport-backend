"""Complete catalog objects, including fields required by the current live API."""
import time
from copy import deepcopy
from typing import Any, cast
from uuid import uuid4

from .models import Account, Tag, Merchant
from .protocol import EntityData, encode_json, timestamp


def _base(user: int, title: str, id: str | None, now: int | None) -> EntityData:
    if type(user) is not int or user <= 0:
        raise ValueError('Expected a positive user ID')
    if not isinstance(title, str) or not title.strip():
        raise ValueError('Expected a nonempty title')
    if id is not None and (not isinstance(id, str) or not id):
        raise ValueError('Expected a nonempty ID')
    return dict(id=str(uuid4()) if id is None else id, user=user, title=title,
                changed=timestamp(int(time.time()) if now is None else now))


def _extend(result: EntityData, fields: EntityData) -> EntityData:
    if any(k in fields for k in ('id', 'user', 'title', 'changed')):
        raise ValueError('Identity fields must use the explicit constructor parameters')
    result.update(deepcopy(fields))
    encode_json(result)
    return result


def account(*, user: int, title: str, instrument: int, account_type: str = 'cash',
            id: str | None = None, now: int | None = None, **fields: Any) -> Account:
    if type(instrument) is not int or instrument <= 0:
        raise ValueError('Expected a positive instrument ID')
    if account_type not in ('cash', 'ccard', 'checking', 'loan', 'deposit', 'emoney'):
        raise ValueError('Unsupported new account type; use the existing system debt account')
    result = _base(user, title, id, now)
    result.update(role=None, instrument=instrument, company=None, type=account_type,
        syncID=None, balance=0, startBalance=0, creditLimit=None, inBalance=True,
        savings=False, enableCorrection=False, enableSMS=False, archive=False,
        private=False, balanceCorrectionType='request', capitalization=None,
        percent=None, startDate=None, endDateOffset=None, endDateOffsetInterval=None,
        payoffStep=None, payoffInterval=None)
    result = _extend(result, fields)
    if account_type in ('loan', 'deposit') and any(result.get(k) is None for k in
            ('capitalization', 'percent', 'startDate', 'endDateOffset', 'endDateOffsetInterval')):
        raise ValueError('Loan/deposit parameters are required')
    return cast(Account, result)


def tag(*, user: int, title: str, id: str | None = None,
        now: int | None = None, **fields: Any) -> Tag:
    result = _base(user, title, id, now)
    result.update(parent=None, icon=None, picture=None, color=None, showIncome=True,
        showOutcome=True, budgetIncome=True, budgetOutcome=True, required=False,
        archive=False, staticId=None)
    return cast(Tag, _extend(result, fields))


def merchant(*, user: int, title: str, id: str | None = None,
             now: int | None = None, **fields: Any) -> Merchant:
    result = _base(user, title, id, now)
    result['mcc'] = None
    return cast(Merchant, _extend(result, fields))
