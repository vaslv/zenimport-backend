"""Lossless wire protocol; accepts complete objects and preserves extensions."""
from collections.abc import Iterable, Mapping, Sequence
from copy import deepcopy
from decimal import Decimal
from math import isfinite
from typing import Any, TypeAlias, cast

import simplejson as json

from .errors import ResponseError

EntityData: TypeAlias = dict[str, Any]
Changes: TypeAlias = Mapping[str, Sequence[Mapping[str, Any]]]
KINDS = ('instrument', 'company', 'user', 'account', 'tag', 'merchant',
         'budget', 'reminder', 'reminderMarker', 'transaction', 'country')
FORCE_FETCH = tuple(kind for kind in KINDS if kind != 'country')
WRITABLE = ('account', 'tag', 'merchant', 'budget', 'reminder', 'reminderMarker', 'transaction')
DELETABLE = tuple(kind for kind in WRITABLE if kind != 'budget')


class Diff(dict[str, Any]):
    """Decoded entities, including unknown fields, and the unchanged UTF-8 response."""
    def __init__(self, data: EntityData, raw_json: str):
        super().__init__(data)
        self.raw_json = raw_json

    @property
    def server_timestamp(self) -> int:
        return int(self['serverTimestamp'])


def entity_key(kind: str, item: Mapping[str, Any]) -> str:
    if kind == 'budget':
        if not all(k in item for k in ('user', 'date', 'tag')):
            raise ResponseError('Invalid budget key')
        if type(item['user']) is not int or item['user'] <= 0 or not isinstance(item['date'], str):
            raise ResponseError('Invalid budget key')
        if item['tag'] is not None and not isinstance(item['tag'], str):
            raise ResponseError('Invalid budget key')
        return str(json.dumps([item['user'], item['date'], item['tag']], separators=(',', ':')))
    identifier = item.get('id')
    if type(identifier) not in (str, int) or identifier == '':
        raise ResponseError('Invalid entity identifier')
    return str(identifier)


def validate_diff(data: Any) -> None:
    if not isinstance(data, dict) or type(data.get('serverTimestamp')) is not int or data['serverTimestamp'] < 0:
        raise ResponseError('Invalid server timestamp')
    if data.get('error'):
        raise ResponseError('ZenMoney rejected diff')
    for kind in KINDS:
        rows = data.get(kind, [])
        if not isinstance(rows, list):
            raise ResponseError('Invalid entity collection')
        for row in rows:
            if not isinstance(row, dict):
                raise ResponseError('Invalid entity')
            entity_key(kind, row)
    if not isinstance(data.get('deletion', []), list):
        raise ResponseError('Invalid deletions')
    for row in data.get('deletion', []):
        if not isinstance(row, dict) or not isinstance(row.get('object'), str) or type(row.get('id')) not in (str, int):
            raise ResponseError('Invalid deletion')


def _unique_object(pairs: list[tuple[str, Any]]) -> EntityData:
    result: EntityData = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key')
        result[key] = value
    return result


def _validate_json(value: Any, seen: set[int] | None = None) -> None:
    """Reject coercions, circular values and nonfinite Decimals before encoding."""
    if value is None or type(value) in (str, int, bool):
        return
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError('Expected a finite decimal')
        return
    if type(value) is float:
        if not isfinite(value):
            raise ValueError('Expected a finite number')
        return
    if isinstance(value, (dict, list, tuple)):
        seen = set() if seen is None else seen
        if id(value) in seen:
            raise ValueError('Circular JSON value')
        seen.add(id(value))
        try:
            values: Iterable[Any]
            if isinstance(value, dict):
                if not all(isinstance(key, str) for key in value):
                    raise ValueError('JSON keys must be strings')
                values = value.values()
            else:
                values = value
            for item in values:
                _validate_json(item, seen)
        finally:
            seen.remove(id(value))
        return
    raise ValueError('Unsupported JSON value')


def decode_json(raw: bytes) -> Any:
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_object,
                          use_decimal=True, allow_nan=False)
    except (ValueError, UnicodeError, RecursionError):
        raise ResponseError('Invalid ZenMoney JSON') from None


def decode_diff(raw: bytes, cursor: int) -> Diff:
    data = decode_json(raw)
    validate_diff(data)
    if data['serverTimestamp'] < cursor:
        raise ResponseError('ZenMoney cursor moved backwards')
    return Diff(data, raw.decode('utf-8'))


def timestamp(value: Any) -> int:
    if type(value) is not int or value < 0:
        raise ValueError('Expected a nonnegative integer timestamp')
    return int(value)


def encode_json(value: Any) -> bytes:
    try:
        _validate_json(value)
        return json.dumps(value, ensure_ascii=False, allow_nan=False,
                          use_decimal=True).encode('utf-8')
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise ValueError('Expected finite JSON values with string keys') from None


def _sequence(value: Any) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray))


def diff_payload(cursor: int, now: int, changes: Changes | None = None,
                 deletions: Sequence[Mapping[str, Any]] | None = None,
                 force_fetch: Sequence[str] | None = None) -> EntityData:
    payload: EntityData = {'serverTimestamp': timestamp(cursor), 'currentClientTimestamp': timestamp(now)}
    if force_fetch is not None:
        if not _sequence(force_fetch) or any(not isinstance(k, str) or k not in FORCE_FETCH for k in force_fetch):
            raise ValueError('Unsupported forceFetch collection')
        payload['forceFetch'] = list(dict.fromkeys(force_fetch))
    if changes is not None:
        if not isinstance(changes, Mapping) or any(k not in WRITABLE for k in changes):
            raise ValueError('Only user entity collections can be written')
        for kind, rows in changes.items():
            if not _sequence(rows):
                raise ValueError('Expected an entity sequence')
            keys = set()
            copied = []
            for row in rows:
                if not isinstance(row, Mapping):
                    raise ValueError('Expected an entity object')
                try:
                    key = entity_key(kind, row)
                except ResponseError:
                    raise ValueError('Invalid entity identity') from None
                # User entity IDs are strings; budgets are keyed by user/date/tag.
                if kind != 'budget' and not isinstance(row['id'], str):
                    raise ValueError('Expected a string entity ID')
                if key in keys:
                    raise ValueError('Duplicate entity identity')
                keys.add(key)
                timestamp(row.get('changed'))
                if type(row.get('user')) is not int or row['user'] <= 0:
                    raise ValueError('Expected positive user ID')
                copied.append(deepcopy(dict(row)))
            payload[kind] = copied
    if deletions is not None:
        if not _sequence(deletions):
            raise ValueError('Expected deletion sequence')
        seen = set()
        copied_deletions = []
        for row in deletions:
            if not isinstance(row, Mapping) or row.get('object') not in DELETABLE or not isinstance(row.get('id'), str) or not row['id']:
                raise ValueError('Invalid deletion identity')
            timestamp(row.get('stamp'))
            if type(row.get('user')) is not int or row['user'] <= 0:
                raise ValueError('Expected positive user ID')
            deletion_key = (row['object'], row['id'])
            if deletion_key in seen or any(t.get('id') == row['id'] for t in payload.get(row['object'], [])):
                raise ValueError('Duplicate or conflicting deletion')
            seen.add(deletion_key)
            copied_deletions.append(deepcopy(dict(row)))
        payload['deletion'] = copied_deletions
    encode_json(payload)
    return payload


def suggest_payload(transactions: Mapping[str, Any] | Sequence[Mapping[str, Any]]) -> EntityData | list[EntityData]:
    payload: EntityData | list[EntityData]
    if isinstance(transactions, Mapping):
        payload = deepcopy(dict(transactions))
    elif _sequence(transactions) and transactions and all(isinstance(t, Mapping) for t in transactions):
        payload = [deepcopy(dict(t)) for t in transactions]
    else:
        raise ValueError('Expected transaction object or nonempty sequence')
    encode_json(payload)
    return payload


def decode_suggestion(raw: bytes, request: EntityData | list[EntityData]) -> EntityData | list[EntityData]:
    result = decode_json(raw)
    if isinstance(request, list):
        valid = isinstance(result, list) and len(result) == len(request) and all(isinstance(t, dict) and not t.get('error') for t in result)
    else:
        valid = isinstance(result, dict) and not result.get('error')
    if not valid:
        raise ResponseError('Invalid suggestion response')
    return cast(EntityData | list[EntityData], result)
