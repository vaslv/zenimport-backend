"""Explicit OAuth code exchange/refresh; secrets and tokens have redacted reprs."""
from dataclasses import dataclass, field
from typing import Any, Generic, Self, TypeVar
from urllib.parse import urlencode, urlsplit, parse_qs
from hmac import compare_digest
import httpx
from .client import BASE_URL, Timeout, validate_timeout
from .errors import ClientClosedError, HTTPError, TransportError, ResponseError
from .protocol import decode_json


def authorization_url(client_id: str, redirect_uri: str, *, state: str) -> str:
    if not all(isinstance(v, str) and v for v in (client_id, redirect_uri, state)):
        raise ValueError('client_id, redirect_uri and unpredictable state are required')
    return BASE_URL + '/oauth2/authorize/?' + urlencode(dict(response_type='code', client_id=client_id, redirect_uri=redirect_uri, state=state))


def callback_code(callback_url: str, *, expected_state: str) -> str:
    if not isinstance(callback_url, str) or not isinstance(expected_state, str) or not expected_state:
        raise ValueError('Callback URL and expected state are required')
    query = parse_qs(urlsplit(callback_url).query, keep_blank_values=True)
    states, codes = query.get('state', []), query.get('code', [])
    if not expected_state or len(states) != 1 or not compare_digest(states[0].encode(), expected_state.encode()):
        raise ValueError('OAuth state mismatch')
    if 'error' in query or len(codes) != 1 or not codes[0]:
        raise ResponseError('OAuth authorization was not completed')
    return codes[0]


@dataclass(frozen=True)
class Token:
    access_token: str = field(repr=False)
    token_type: str = 'bearer'
    expires_in: int | None = None
    refresh_token: str | None = field(default=None, repr=False)


def _token(raw: bytes) -> Token:
    data = decode_json(raw)
    if not isinstance(data, dict) or not isinstance(data.get('access_token'), str) or not data['access_token'] or any(c.isspace() for c in data['access_token']) or str(data.get('token_type', '')).lower() != 'bearer':
        raise ResponseError('Invalid OAuth token response')
    if data.get('expires_in') is not None and (type(data['expires_in']) is not int or data['expires_in'] < 0):
        raise ResponseError('Invalid OAuth token lifetime')
    if data.get('refresh_token') is not None and (not isinstance(data['refresh_token'], str) or not data['refresh_token']):
        raise ResponseError('Invalid refresh token')
    return Token(data['access_token'], 'bearer', data.get('expires_in'), data.get('refresh_token'))


Transport = TypeVar('Transport', httpx.BaseTransport, httpx.AsyncBaseTransport)


class _OAuthConfig(Generic[Transport]):
    def __init__(self, client_id: str, client_secret: str, redirect_uri: str,
                 *, transport: Transport | None = None, timeout: Timeout = 60):
        if not all(isinstance(v, str) and v for v in (client_id, client_secret, redirect_uri)):
            raise ValueError('OAuth application credentials are required')
        validate_timeout(timeout)
        self._id, self._secret, self._redirect = client_id, client_secret, redirect_uri
        self._transport: Transport | None = transport
        self._timeout = timeout
        self._closed = False

    @property
    def is_closed(self) -> bool:
        return self._closed

    def _check_open(self) -> None:
        if self._closed:
            raise ClientClosedError('ZenMoney OAuth client is closed')

    def authorization_url(self, *, state: str) -> str:
        return authorization_url(self._id, self._redirect, state=state)

    def _form(self, grant_type: str, value: str) -> dict[str, str]:
        self._check_open()
        if not isinstance(value, str) or not value:
            raise ValueError('Nonempty code or refresh token required')
        form = dict(grant_type=grant_type, client_id=self._id, client_secret=self._secret)
        if grant_type == 'authorization_code':
            form.update(code=value, redirect_uri=self._redirect)
        else:
            form['refresh_token'] = value
        return form


class OAuthClient(_OAuthConfig[httpx.BaseTransport]):
    _http: httpx.Client | None = None

    def __enter__(self) -> Self:
        self._check_open()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            if self._http is not None:
                self._http.close()
                self._http = None
            elif self._transport is not None:
                self._transport.close()

    def _request(self, form: dict[str, str]) -> Token:
        self._check_open()
        try:
            if self._http is None:
                self._http = httpx.Client(transport=self._transport, timeout=self._timeout, trust_env=False, follow_redirects=False)
            with self._http.stream('POST', BASE_URL+'/oauth2/token/', data=form) as response:
                if response.status_code != 200:
                    raise HTTPError(response.status_code)
                body = bytearray()
                for chunk in response.iter_bytes():
                    if len(body)+len(chunk) > 1024*1024:
                        raise ResponseError('OAuth response exceeds limit')
                    body.extend(chunk)
                return _token(bytes(body))
        except httpx.HTTPError:
            raise TransportError('OAuth connection failed') from None

    def exchange_code(self, code: str) -> Token:
        return self._request(self._form('authorization_code', code))

    def refresh(self, refresh_token: str) -> Token:
        return self._request(self._form('refresh_token', refresh_token))


class AsyncOAuthClient(_OAuthConfig[httpx.AsyncBaseTransport]):
    _http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> Self:
        self._check_open()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if not self._closed:
            self._closed = True
            if self._http is not None:
                await self._http.aclose()
                self._http = None
            elif self._transport is not None:
                await self._transport.aclose()

    async def _request(self, form: dict[str, str]) -> Token:
        self._check_open()
        try:
            if self._http is None:
                self._http = httpx.AsyncClient(transport=self._transport, timeout=self._timeout, trust_env=False, follow_redirects=False)
            async with self._http.stream('POST', BASE_URL+'/oauth2/token/', data=form) as response:
                if response.status_code != 200:
                    raise HTTPError(response.status_code)
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    if len(body)+len(chunk) > 1024*1024:
                        raise ResponseError('OAuth response exceeds limit')
                    body.extend(chunk)
                return _token(bytes(body))
        except httpx.HTTPError:
            raise TransportError('OAuth connection failed') from None

    async def exchange_code(self, code: str) -> Token:
        return await self._request(self._form('authorization_code', code))

    async def refresh(self, refresh_token: str) -> Token:
        return await self._request(self._form('refresh_token', refresh_token))
