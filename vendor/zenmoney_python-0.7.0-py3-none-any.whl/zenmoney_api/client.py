"""Synchronous/asynchronous public API clients with explicit resource ownership."""
from collections.abc import Callable, Mapping, Sequence
from math import isfinite
import time
from typing import Any, Generic, Self, TypeVar, overload

import httpx

from .errors import ClientClosedError, HTTPError, ResponseError, TransportError
from .protocol import Changes, Diff, EntityData, diff_payload, decode_diff, encode_json, suggest_payload, decode_suggestion

BASE_URL = 'https://api.zenmoney.ru'
ENDPOINT = BASE_URL + '/v8/diff/'
Timeout = float | httpx.Timeout | None
Transport = TypeVar('Transport', httpx.BaseTransport, httpx.AsyncBaseTransport)


def validate_timeout(timeout: Timeout) -> None:
    values = (timeout.connect, timeout.read, timeout.write, timeout.pool) if isinstance(timeout, httpx.Timeout) else (timeout,)
    if any(value is not None and (type(value) not in (int, float) or not isfinite(value) or value <= 0) for value in values):
        raise ValueError('Timeouts must be positive finite numbers or None')


class _Config(Generic[Transport]):
    def __init__(self, token: str, *, transport: Transport | None = None,
                 timeout: Timeout = 60, max_response_bytes: int = 64*1024*1024,
                 clock: Callable[[], float] = time.time):
        if not isinstance(token, str) or not token or any(c.isspace() for c in token):
            raise ValueError('A nonempty bearer token without whitespace is required')
        if type(max_response_bytes) is not int or max_response_bytes <= 0:
            raise ValueError('Response limit must be a positive integer')
        validate_timeout(timeout)
        self._token = token
        self._transport: Transport | None = transport
        self._timeout, self._limit, self._clock = timeout, max_response_bytes, clock
        self._closed = False

    @property
    def is_closed(self) -> bool:
        return self._closed

    def _check_open(self) -> None:
        if self._closed:
            raise ClientClosedError('ZenMoney client is closed')

    def _options(self) -> dict[str, Any]:
        return dict(timeout=self._timeout, transport=self._transport, follow_redirects=False, trust_env=False)


class Client(_Config[httpx.BaseTransport]):
    _http: httpx.Client | None = None

    def __enter__(self) -> Self:
        self._check_open()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            if self._http is not None:
                self._http.close()
                self._http = None

    def _request(self, path: str, payload: Any) -> bytes:
        self._check_open()
        content = encode_json(payload)
        try:
            if self._http is None:
                self._http = httpx.Client(**self._options())
            with self._http.stream('POST', BASE_URL+path, headers={'Authorization': f'Bearer {self._token}', 'Content-Type': 'application/json'}, content=content) as response:
                if response.status_code != 200:
                    raise HTTPError(response.status_code)
                body = bytearray()
                for chunk in response.iter_bytes():
                    if len(body)+len(chunk) > self._limit:
                        raise ResponseError('ZenMoney response exceeds configured limit')
                    body.extend(chunk)
                return bytes(body)
        except httpx.HTTPError:
            raise TransportError('ZenMoney connection failed') from None

    def diff(self, server_timestamp: int = 0, *, changes: Changes | None = None,
             deletions: Sequence[Mapping[str, Any]] | None = None,
             force_fetch: Sequence[str] | None = None) -> Diff:
        """Exchange complete objects; persist the cursor only after storing returned data."""
        payload = diff_payload(server_timestamp, int(self._clock()), changes, deletions, force_fetch)
        return decode_diff(self._request('/v8/diff/', payload), server_timestamp)

    def read_diff(self, server_timestamp: int = 0, *, force_fetch: Sequence[str] | None = None) -> Diff:
        return self.diff(server_timestamp, force_fetch=force_fetch)

    def upsert(self, kind: str, entities: Sequence[Mapping[str, Any]], server_timestamp: int = 0) -> Diff:
        """Send complete objects; timestamps resolve conflicts on the server."""
        return self.diff(server_timestamp, changes={kind: entities})

    def delete(self, deletions: Sequence[Mapping[str, Any]], server_timestamp: int = 0) -> Diff:
        return self.diff(server_timestamp, deletions=deletions)

    @overload
    def suggest(self, transactions: Mapping[str, Any]) -> EntityData: ...
    @overload
    def suggest(self, transactions: Sequence[Mapping[str, Any]]) -> list[EntityData]: ...
    def suggest(self, transactions: Mapping[str, Any] | Sequence[Mapping[str, Any]]) -> EntityData | list[EntityData]:
        payload = suggest_payload(transactions)
        return decode_suggestion(self._request('/v8/suggest/', payload), payload)


class AsyncClient(_Config[httpx.AsyncBaseTransport]):
    _http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> Self:
        self._check_open()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if not self._closed:
            self._closed = True
            if self._http is not None:
                await self._http.aclose()
                self._http = None

    async def _request(self, path: str, payload: Any) -> bytes:
        self._check_open()
        content = encode_json(payload)
        try:
            if self._http is None:
                self._http = httpx.AsyncClient(**self._options())
            async with self._http.stream('POST', BASE_URL+path, headers={'Authorization': f'Bearer {self._token}', 'Content-Type': 'application/json'}, content=content) as response:
                if response.status_code != 200:
                    raise HTTPError(response.status_code)
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    if len(body)+len(chunk) > self._limit:
                        raise ResponseError('ZenMoney response exceeds configured limit')
                    body.extend(chunk)
                return bytes(body)
        except httpx.HTTPError:
            raise TransportError('ZenMoney connection failed') from None

    async def diff(self, server_timestamp: int = 0, *, changes: Changes | None = None,
                   deletions: Sequence[Mapping[str, Any]] | None = None,
                   force_fetch: Sequence[str] | None = None) -> Diff:
        payload = diff_payload(server_timestamp, int(self._clock()), changes, deletions, force_fetch)
        return decode_diff(await self._request('/v8/diff/', payload), server_timestamp)

    async def read_diff(self, server_timestamp: int = 0, *, force_fetch: Sequence[str] | None = None) -> Diff:
        return await self.diff(server_timestamp, force_fetch=force_fetch)

    async def upsert(self, kind: str, entities: Sequence[Mapping[str, Any]], server_timestamp: int = 0) -> Diff:
        return await self.diff(server_timestamp, changes={kind: entities})

    async def delete(self, deletions: Sequence[Mapping[str, Any]], server_timestamp: int = 0) -> Diff:
        return await self.diff(server_timestamp, deletions=deletions)

    @overload
    async def suggest(self, transactions: Mapping[str, Any]) -> EntityData: ...
    @overload
    async def suggest(self, transactions: Sequence[Mapping[str, Any]]) -> list[EntityData]: ...
    async def suggest(self, transactions: Mapping[str, Any] | Sequence[Mapping[str, Any]]) -> EntityData | list[EntityData]:
        payload = suggest_payload(transactions)
        return decode_suggestion(await self._request('/v8/suggest/', payload), payload)
