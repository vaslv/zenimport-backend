"""Builders produce full wire objects; they never send or persist anything."""
import math
import time
from copy import deepcopy
from datetime import date as Date
from uuid import uuid4
from .protocol import DELETABLE, timestamp, encode_json

CREATION_DEFAULTS = {key: None for key in (
    'merchant', 'originalPayee', 'reminderMarker', 'opIncome', 'opIncomeInstrument',
    'opOutcome', 'opOutcomeInstrument', 'latitude', 'longitude', 'qrCode', 'source',
    'incomeBankID', 'outcomeBankID')}
CREATION_DEFAULTS['viewed'] = True


def _amount(value, *, positive=False):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0 or (positive and value == 0):
        raise ValueError('Expected a finite nonnegative amount')
    return value


def _id(value):
    if not isinstance(value, str) or not value:
        raise ValueError('Expected a nonempty account ID')
    return value


def _positive_int(value):
    if type(value) is not int or value <= 0:
        raise ValueError('Expected a positive integer ID')
    return value


def transaction(*, user: int, date: str, income_account: str, outcome_account: str,
                income_instrument: int, outcome_instrument: int, income: int | float,
                outcome: int | float, categories: list[str] | None = None,
                payee: str | None = None, comment: str | None = None,
                merchant: str | None = None, id: str | None = None,
                now: int | None = None, **fields) -> dict:
    """Build a posted operation. IDs/timestamps can be supplied for deterministic drafts."""
    if not isinstance(date, str) or Date.fromisoformat(date).isoformat() != date:
        raise ValueError('Expected ISO calendar date')
    stamp = timestamp(int(time.time()) if now is None else now)
    if categories is not None and (not isinstance(categories, list) or not all(isinstance(t, str) and t for t in categories)):
        raise ValueError('Expected category IDs or None')
    for value in (payee, comment, merchant):
        if value is not None and not isinstance(value, str):
            raise ValueError('Expected optional text')
    result = {**CREATION_DEFAULTS, 'mcc': None, 'id': _id(id) if id is not None else str(uuid4()),
        'created': stamp, 'changed': stamp, 'user': _positive_int(user), 'deleted': False, 'hold': False,
        'date': date, 'incomeAccount': _id(income_account), 'outcomeAccount': _id(outcome_account),
        'incomeInstrument': _positive_int(income_instrument), 'outcomeInstrument': _positive_int(outcome_instrument),
        'income': _amount(income), 'outcome': _amount(outcome), 'tag': deepcopy(categories),
        'payee': payee, 'comment': comment, 'merchant': merchant}
    allowed = set(CREATION_DEFAULTS) | {'mcc', 'hold', 'deleted'}
    if any(k not in allowed for k in fields):
        raise ValueError('Unsupported optional transaction field')
    result.update(fields)
    for name in ('opIncome', 'opOutcome'):
        if result[name] is not None:
            _amount(result[name])
        if (result[name] is None) != (result[name+'Instrument'] is None):
            raise ValueError('Original amount and instrument must be supplied together')
        if result[name+'Instrument'] is not None:
            _positive_int(result[name+'Instrument'])
    for name, limit in (('latitude', 90), ('longitude', 180)):
        if result[name] is not None and (type(result[name]) not in (int, float) or not math.isfinite(result[name]) or not -limit <= result[name] <= limit):
            raise ValueError('Invalid coordinates')
    if type(result['deleted']) is not bool or (result['hold'] is not None and type(result['hold']) is not bool):
        raise ValueError('Invalid transaction flags')
    encode_json(result)
    return result


def expense(*, account: str, instrument: int, amount: int | float, **kwargs) -> dict:
    return transaction(income_account=account, outcome_account=account,
        income_instrument=instrument, outcome_instrument=instrument,
        income=0, outcome=_amount(amount, positive=True), **kwargs)


def income(*, account: str, instrument: int, amount: int | float, **kwargs) -> dict:
    return transaction(income_account=account, outcome_account=account,
        income_instrument=instrument, outcome_instrument=instrument,
        income=_amount(amount, positive=True), outcome=0, **kwargs)


def transfer(*, from_account: str, to_account: str, from_instrument: int,
             to_instrument: int, amount_out: int | float, amount_in: int | float, **kwargs) -> dict:
    if from_account == to_account:
        raise ValueError('Transfer requires different accounts')
    return transaction(income_account=to_account, outcome_account=from_account,
        income_instrument=to_instrument, outcome_instrument=from_instrument,
        income=_amount(amount_in, positive=True), outcome=_amount(amount_out, positive=True), **kwargs)


def debt(*, action: str, account: str, debt_account: str, instrument: int,
         amount: int | float, payee: str, **kwargs) -> dict:
    """lend/repay: cash → debt; borrow/collect: debt → cash. Both use cash currency."""
    if action not in ('lend', 'borrow', 'repay', 'collect'):
        raise ValueError('Unknown debt action')
    if not isinstance(payee, str) or not payee.strip():
        raise ValueError('Debt requires a counterparty')
    outgoing = action in ('lend', 'repay')
    return transfer(from_account=account if outgoing else debt_account,
        to_account=debt_account if outgoing else account,
        from_instrument=instrument, to_instrument=instrument,
        amount_out=amount, amount_in=amount, payee=payee, **kwargs)


def update(entity: dict, *, now: int | None = None, **fields) -> dict:
    """Copy a complete fetched entity, retaining unknown fields. Identity is immutable."""
    if any(k in fields for k in ('id', 'user', 'created', 'changed')):
        raise ValueError('Cannot replace identity or timestamps in an update')
    result = deepcopy(entity)
    result.update(deepcopy(fields))
    result['changed'] = timestamp(int(time.time()) if now is None else now)
    encode_json(result)
    return result


def deletion(kind: str, id: str, *, user: int, now: int | None = None) -> dict:
    if kind not in DELETABLE:
        raise ValueError('This entity cannot be deleted by ID')
    return {'object': kind, 'id': _id(id), 'user': _positive_int(user),
            'stamp': timestamp(int(time.time()) if now is None else now)}


def clear_budget(budget: dict, *, now: int | None = None) -> dict:
    """Budget has a composite identity; clear amounts/locks instead of deleting by ID."""
    return update(budget, now=now, income=0, outcome=0, incomeLock=False, outcomeLock=False)
