import json
from .errors import ResponseError

KINDS = ('instrument', 'company', 'user', 'account', 'tag', 'merchant',
         'budget', 'reminder', 'reminderMarker', 'transaction', 'country')
# Country is observed in responses but not documented as a forceFetch key.
FORCE_FETCH = tuple(kind for kind in KINDS if kind != 'country')


class Diff(dict):
    def __init__(self, data: dict, raw_json: str):
        super().__init__(data)
        self.raw_json = raw_json


def entity_key(kind: str, item: dict) -> str:
    if kind == 'budget':
        if not all(k in item for k in ('user', 'date', 'tag')):
            raise ResponseError('Invalid budget key')
        if type(item['user']) not in (str, int) or not isinstance(item['date'], str):
            raise ResponseError('Invalid budget key')
        if item['tag'] is not None and not isinstance(item['tag'], str):
            raise ResponseError('Invalid budget key')
        return json.dumps([item['user'], item['date'], item['tag']], separators=(',', ':'))
    identifier = item.get('id')
    if type(identifier) not in (str, int) or identifier == '':
        raise ResponseError('Invalid entity identifier')
    return str(identifier)


def validate_diff(data: dict) -> None:
    if not isinstance(data, dict) or type(data.get('serverTimestamp')) is not int or data['serverTimestamp'] < 0:
        raise ResponseError('Invalid server timestamp')
    if data.get('error'):
        raise ResponseError('ZenMoney rejected diff')
    for kind in KINDS:
        rows = data.get(kind, [])
        if not isinstance(rows, list):
            raise ResponseError('Invalid entity collection')
        for row in rows:
            if not isinstance(row, dict):
                raise ResponseError('Invalid entity')
            entity_key(kind, row)
    if not isinstance(data.get('deletion', []), list):
        raise ResponseError('Invalid deletions')
    for row in data.get('deletion', []):
        if not isinstance(row, dict) or not isinstance(row.get('object'), str) or type(row.get('id')) not in (str, int):
            raise ResponseError('Invalid deletion')



WRITABLE = ('account', 'tag', 'merchant', 'budget', 'reminder', 'reminderMarker', 'transaction')
DELETABLE = tuple(k for k in WRITABLE if k != 'budget')


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key')
        result[key] = value
    return result


def _invalid_number(value):
    raise ValueError('Non-finite JSON number')


def decode_json(raw):
    try:
        data = json.loads(raw, object_pairs_hook=_unique_object, parse_constant=_invalid_number)
        json.dumps(data, allow_nan=False)
        return data
    except (ValueError, UnicodeError):
        raise ResponseError('Invalid ZenMoney JSON') from None


def decode_diff(raw, cursor):
    data = decode_json(raw)
    validate_diff(data)
    if data['serverTimestamp'] < cursor:
        raise ResponseError('ZenMoney cursor moved backwards')
    return Diff(data, raw.decode('utf-8'))


def timestamp(value):
    if type(value) is not int or value < 0:
        raise ValueError('Expected a nonnegative integer timestamp')
    return value


def encode_json(value):
    try:
        return json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (ValueError, TypeError):
        raise ValueError('Expected finite JSON values') from None


def diff_payload(cursor, now, changes=None, deletions=None, force_fetch=None):
    payload = {'serverTimestamp': timestamp(cursor), 'currentClientTimestamp': timestamp(now)}
    if force_fetch is not None:
        if isinstance(force_fetch, str) or any(k not in FORCE_FETCH for k in force_fetch):
            raise ValueError('Unsupported forceFetch collection')
        payload['forceFetch'] = list(dict.fromkeys(force_fetch))
    if changes is not None:
        if not isinstance(changes, dict) or any(k not in WRITABLE for k in changes):
            raise ValueError('Only user entity collections can be written')
        for kind, rows in changes.items():
            if not isinstance(rows, list):
                raise ValueError('Expected an entity list')
            keys = set()
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError('Expected an entity object')
                try:
                    key = entity_key(kind, row)
                except ResponseError:
                    raise ValueError('Invalid entity identity') from None
                if key in keys:
                    raise ValueError('Duplicate entity identity')
                keys.add(key)
                timestamp(row.get('changed'))
                if type(row.get('user')) is not int or row['user'] <= 0:
                    raise ValueError('Expected positive user ID')
            payload[kind] = rows
    if deletions is not None:
        if not isinstance(deletions, list):
            raise ValueError('Expected deletion list')
        seen = set()
        for row in deletions:
            if not isinstance(row, dict) or row.get('object') not in DELETABLE or not isinstance(row.get('id'), str) or not row['id']:
                raise ValueError('Invalid deletion identity')
            timestamp(row.get('stamp'))
            if type(row.get('user')) is not int or row['user'] <= 0:
                raise ValueError('Expected positive user ID')
            key = (row['object'], row['id'])
            if key in seen or any(t.get('id') == row['id'] for t in payload.get(row['object'], [])):
                raise ValueError('Duplicate or conflicting deletion')
            seen.add(key)
        payload['deletion'] = deletions
    encode_json(payload)
    return payload


def suggest_payload(transactions):
    if not isinstance(transactions, (dict, list)) or (isinstance(transactions, list) and (not transactions or not all(isinstance(t, dict) for t in transactions))):
        raise ValueError('Expected transaction object or nonempty list')
    encode_json(transactions)
    return transactions


def decode_suggestion(raw, request):
    result = decode_json(raw)
    if isinstance(request, list):
        valid = isinstance(result, list) and len(result) == len(request) and all(isinstance(t, dict) and not t.get('error') for t in result)
    else:
        valid = isinstance(result, dict) and not result.get('error')
    if not valid:
        raise ResponseError('Invalid suggestion response')
    return result
