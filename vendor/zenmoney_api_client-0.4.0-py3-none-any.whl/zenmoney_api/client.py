"""Synchronous/asynchronous API clients. No hidden retries or synchronization state."""
import math
import time
import httpx
from .errors import HTTPError, ResponseError, TransportError
from .protocol import diff_payload, decode_diff, encode_json, suggest_payload, decode_suggestion

BASE_URL = 'https://api.zenmoney.ru'
ENDPOINT = BASE_URL + '/v8/diff/'


class _Config:
    def __init__(self, token, *, transport=None, timeout=60, max_response_bytes=64*1024*1024, clock=time.time):
        if not isinstance(token, str) or not token or any(c.isspace() for c in token):
            raise ValueError('A nonempty bearer token without whitespace is required')
        if type(max_response_bytes) is not int or max_response_bytes <= 0 or type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError('Response limit and timeout must be positive')
        self._token, self._transport = token, transport
        self._timeout, self._limit, self._clock = timeout, max_response_bytes, clock
        self._http = None

    def _options(self):
        return dict(timeout=self._timeout, transport=self._transport, follow_redirects=False, trust_env=False)


class Client(_Config):
    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        if self._http is not None:
            self._http.close()
            self._http = None

    def _request(self, path, payload):
        content = encode_json(payload)
        try:
            if self._http is None:
                self._http = httpx.Client(**self._options())
            with self._http.stream('POST', BASE_URL+path, headers={'Authorization': f'Bearer {self._token}', 'Content-Type': 'application/json'}, content=content) as response:
                if response.status_code != 200:
                    raise HTTPError(response.status_code)
                body = bytearray()
                for chunk in response.iter_bytes():
                    if len(body)+len(chunk) > self._limit:
                        raise ResponseError('ZenMoney response exceeds configured limit')
                    body.extend(chunk)
                return bytes(body)
        except httpx.HTTPError:
            raise TransportError('ZenMoney connection failed') from None

    def diff(self, server_timestamp=0, *, changes=None, deletions=None, force_fetch=None):
        """Read or exchange complete entities. Persist the returned cursor only after storing data."""
        payload = diff_payload(server_timestamp, int(self._clock()), changes, deletions, force_fetch)
        return decode_diff(self._request('/v8/diff/', payload), server_timestamp)

    def read_diff(self, server_timestamp=0, *, force_fetch=None):
        return self.diff(server_timestamp, force_fetch=force_fetch)

    def upsert(self, kind, entities, server_timestamp=0):
        """Send complete objects, not patches. Server changed timestamps resolve conflicts."""
        return self.diff(server_timestamp, changes={kind: entities})

    def delete(self, deletions, server_timestamp=0):
        return self.diff(server_timestamp, deletions=deletions)

    def suggest(self, transactions):
        payload = suggest_payload(transactions)
        return decode_suggestion(self._request('/v8/suggest/', payload), payload)


class AsyncClient(_Config):
    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()

    async def aclose(self):
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def _request(self, path, payload):
        content = encode_json(payload)
        try:
            if self._http is None:
                self._http = httpx.AsyncClient(**self._options())
            async with self._http.stream('POST', BASE_URL+path, headers={'Authorization': f'Bearer {self._token}', 'Content-Type': 'application/json'}, content=content) as response:
                if response.status_code != 200:
                    raise HTTPError(response.status_code)
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    if len(body)+len(chunk) > self._limit:
                        raise ResponseError('ZenMoney response exceeds configured limit')
                    body.extend(chunk)
                return bytes(body)
        except httpx.HTTPError:
            raise TransportError('ZenMoney connection failed') from None

    async def diff(self, server_timestamp=0, *, changes=None, deletions=None, force_fetch=None):
        payload = diff_payload(server_timestamp, int(self._clock()), changes, deletions, force_fetch)
        return decode_diff(await self._request('/v8/diff/', payload), server_timestamp)

    async def read_diff(self, server_timestamp=0, *, force_fetch=None):
        return await self.diff(server_timestamp, force_fetch=force_fetch)

    async def upsert(self, kind, entities, server_timestamp=0):
        return await self.diff(server_timestamp, changes={kind: entities})

    async def delete(self, deletions, server_timestamp=0):
        return await self.diff(server_timestamp, deletions=deletions)

    async def suggest(self, transactions):
        payload = suggest_payload(transactions)
        return decode_suggestion(await self._request('/v8/suggest/', payload), payload)
