"""Errors contain no response bodies, credentials or financial data."""
class ZenMoneyError(Exception):
    pass


class TransportError(ZenMoneyError):
    """The outcome of a write may be unknown. Do not automatically retry."""


class ResponseError(ZenMoneyError):
    pass


class HTTPError(ZenMoneyError):
    def __init__(self, status_code: int):
        self.status_code = status_code
        super().__init__(f'ZenMoney HTTP {status_code}')
