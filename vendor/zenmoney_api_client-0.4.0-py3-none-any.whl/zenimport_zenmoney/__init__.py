"""Compatibility facade for ZenImport 0.3: guarded writes, stable imports."""
import math
import uuid
from datetime import date
from zenmoney_api import Client as APIClient
from zenmoney_api.errors import ZenMoneyError, HTTPError, TransportError, ResponseError
from zenmoney_api.protocol import Diff, KINDS, FORCE_FETCH, entity_key, validate_diff
from zenmoney_api.transactions import CREATION_DEFAULTS
from zenmoney_api.client import ENDPOINT

class Client(APIClient):
    @staticmethod
    def _category_payloads(changes, server_timestamp=0):
        if type(server_timestamp) is not int or server_timestamp < 0 or not changes or len(changes) > 20:
            raise ValueError('Invalid category update request')
        transactions = []
        for before, payload in changes:
            if not before.get('id') or before.get('deleted') or before.get('hold') or before.get('incomeAccount') != before.get('outcomeAccount'):
                raise ValueError('Cannot categorize this transaction')
            if not isinstance(payload.get('tag'), list) or len(payload['tag']) != 1 or not isinstance(payload['tag'][0], str) or not payload['tag'][0]:
                raise ValueError('Expected one category')
            if type(payload.get('changed')) is not int:
                raise ValueError('Expected changed timestamp')
            clean = lambda item: {k:v for k,v in item.items() if k not in ('tag', 'changed')}
            if clean(before) != clean(payload):
                raise ValueError('Only category updates are allowed')
            transactions.append(payload)
        if len({t['id'] for t in transactions}) != len(transactions):
            raise ValueError('Duplicate transaction')
        return transactions

    def update_categories(self, changes, server_timestamp=0):
        return self.write_transactions([], changes, server_timestamp)

    @staticmethod
    def _creation_payloads(transactions, server_timestamp=0):
        if type(server_timestamp) is not int or server_timestamp < 0 or not 1 <= len(transactions) <= 20:
            raise ValueError('Invalid creation request')
        allowed = {'id','user','created','changed','deleted','hold','date','incomeAccount','outcomeAccount',
                   'incomeInstrument','outcomeInstrument','income','outcome','tag','payee','comment'}
        for tx in transactions:
            if set(tx) != allowed or uuid.UUID(tx['id']).version != 4:
                raise ValueError('Expected a new UUID and supported creation fields')
            date.fromisoformat(tx['date'])
            if any(type(tx[k]) is not int or tx[k] <= 0 for k in ('user','created','changed','incomeInstrument','outcomeInstrument')):
                raise ValueError('Invalid identity or timestamps')
            if tx['deleted'] is not False or tx['hold'] is not False:
                raise ValueError('Only posted transactions may be created')
            if not tx['incomeAccount'] or tx['incomeAccount'] != tx['outcomeAccount'] or tx['incomeInstrument'] != tx['outcomeInstrument']:
                raise ValueError('Only single-account income or expense is supported')
            if any(type(tx[k]) not in (int,float) or not math.isfinite(tx[k]) or tx[k]<0 for k in ('income','outcome')) or (tx['income']>0)==(tx['outcome']>0):
                raise ValueError('Expected one positive amount')
            if tx['tag'] is not None and (not isinstance(tx['tag'],list) or len(tx['tag'])!=1 or not isinstance(tx['tag'][0],str) or not tx['tag'][0]):
                raise ValueError('Expected one category or null')
            if not isinstance(tx['comment'],str) or (tx['payee'] is not None and not isinstance(tx['payee'],str)):
                raise ValueError('Invalid description')
        if len({t['id'] for t in transactions}) != len(transactions): raise ValueError('Duplicate UUID')
        return [{**CREATION_DEFAULTS, **tx} for tx in transactions]

    def create_transactions(self, transactions, server_timestamp=0):
        return self.write_transactions(transactions, [], server_timestamp)

    def write_transactions(self, creations, changes, server_timestamp=0):
        if not 1 <= len(creations)+len(changes) <= 20:
            raise ValueError('Expected between 1 and 20 changes')
        transactions = (self._creation_payloads(creations, server_timestamp) if creations else []) + (self._category_payloads(changes, server_timestamp) if changes else [])
        if len({t['id'] for t in transactions}) != len(transactions):
            raise ValueError('Duplicate transaction across batch')
        return self._exchange({'currentClientTimestamp':int(self._clock()),'serverTimestamp':server_timestamp,'transaction':transactions})

    def _exchange(self, payload):
        from zenmoney_api.protocol import decode_diff
        return decode_diff(self._request('/v8/diff/', payload), payload['serverTimestamp'])

    def _request(self, path, payload):
        # Legacy callers construct a client per call without a context manager.
        try:
            return super()._request(path, payload)
        finally:
            self.close()
